﻿#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#include <unordered_map>
#include <fstream>
#include <stdio.h>
#include <string>
#include <set>
#include <sstream>
#include <algorithm>

using namespace std;
#pragma once

class Edge {
private:
    int from;
    int to;
public:
    Edge();
    Edge(int from, int to);
    int GetFrom();
    int GetTo();
    void SetFrom(int from);
    void SetTo(int to);
    int LoadData(int pocetVrcholu, vector<Edge>& edges);
};

class Graph
{
private:
    vector<vector<int>> adjacencyList;
    vector<bool> visited;
    unordered_map<int, vector<int>> gate;
public:
    Graph(vector<Edge>& edges, int pocetVrcholu);
    void FindBigComponent(int pocetVrcholu, vector<int>& BigComp, vector<int>& BigCompHelp);
    void DFS(int index, vector<int>& BigCompHelp);   // do hloubky
    vector<int> BFS(int prvek, int pocetVrcholu);    // do sirky
    void Centralita(vector<int> dist, int prvek, int pocetVrcholu, int citatel);
    int MoovDoTabulce(vector<int> BigComp);
};

