﻿#include <iostream>
#include "Graph.h"


int main()
{
    Edge* edge = new Edge();
    vector<Edge> edges;
    int pocetVrcholu = 0;
    edges.reserve(1000000);
    pocetVrcholu = edge->LoadData(pocetVrcholu,edges);

    Graph* graph = new Graph(edges, pocetVrcholu);
    vector<int> BigComp;
    vector<int> BigCompHelp;

    graph->FindBigComponent(pocetVrcholu, BigComp, BigCompHelp);
    int citatel = (int)graph->MoovDoTabulce(BigComp) - 1;

    printf("ID\tCentralita\tCentralita Result\n");
    for (int prvek : BigComp) {
        vector<int> dist;
        dist = graph->BFS(prvek, pocetVrcholu);
        graph->Centralita(dist, prvek, pocetVrcholu, citatel);
    }
    return 0;
}