﻿#include "Graph.h"

//Nerozuměl jsem tomu, jak vytvořit soubor Doxygen, a tak jsem napsal fungování s funkcí v
//konkatenaci nad ním. Při obhajobě všechny tyto komentáře smažu.Nechci, abyste měli dojem,
//že jsem tyto komentáře vytvořil pro lepší odpověď na obhajobu projektu :)

Edge::Edge() : Edge(0, 0)
{
}

Edge::Edge(int from, int to)
{
    this->from = from;
    this->to = to;
}

int Edge::GetFrom()
{
    return this->from;
}

int Edge::GetTo()
{
    return this->to;
}

void Edge::SetFrom(int from)
{
    this->from = from;
}

void Edge::SetTo(int to)
{
    this->to = to;
}

/* Funkce pro zápis všech hran do vektoru. Funkce vrací počet vrcholů grafu. */
/* Tato funkce načte soubor "file.txt", na základě dat vytvoří objekty Edge, uloží je do vektoru "edges"
a určí maximální hodnotu z polí "from" a "to". Poté vrátí aktualizovaný počet vrcholů. */
int Edge::LoadData(int pocetVrcholu, vector<Edge>& edges) {
    ifstream file("file.txt");
    if (!file.is_open()) {
        printf("File not found");
        return false;
    }
    string line;
    while (getline(file, line)) {
        istringstream tokenStream(line);
        string token;
        int from, to;
        getline(tokenStream, token, ' ');
        from = std::stoi(token);
        getline(tokenStream, token, ' ');
        to = std::stoi(token);
        edges.push_back(Edge{ from,to });
        pocetVrcholu++;
    }
    file.close();
    int max = 0;
    for (int i = 0; i < pocetVrcholu; i++) {
        if (edges[i].GetFrom() > max) {
            max = edges[i].GetFrom();
        }
        if (edges[i].GetTo() > max) {
            max = edges[i].GetTo();
        }
    }
    pocetVrcholu = max + 1;
    return pocetVrcholu;
}

/* Konstruktor grafu, který naplní vektor adjacencí (adjacencyList) */
/* Tato funkce vytvoří graf na základě vektoru objektů Edge a zadaného počtu vrcholů. Změní velikost seznamu přilehlostí a seznamu
navštívených vrcholů podle počtu vrcholů. Poté přidá do grafu hrany spojením vrcholů z objektů Edge v seznamu adjacencí. */
Graph::Graph(vector<Edge>& edges, int pocetVrcholu) {
    this->adjacencyList.resize(pocetVrcholu);
    this->visited.resize(pocetVrcholu);

    for (Edge& edge : edges) {
        this->adjacencyList[edge.GetFrom()].push_back(edge.GetTo());
        this->adjacencyList[edge.GetTo()].push_back(edge.GetFrom());
    }
}

/* Funkce pro nalezení největší komponenty grafu */
/* Tato funkce najde největší složku konektivity v grafu. K identifikaci komponenty použije hloubkové procházení (DFS),
naplní vektor BigComp největší komponentou a vymaže pomocný vektor BigCompHelp pro další iteraci. */
void Graph::FindBigComponent(int pocetVrcholu, vector<int>& BigComp, vector<int>& BigCompHelp) {
    for (int i = 0; i < pocetVrcholu; i++) {
        if (!this->visited[i]) {
            DFS(i, BigCompHelp);

            if (BigComp.size() <= BigCompHelp.size()) {
                BigComp.clear();
                for (int prvek : BigCompHelp) {
                    BigComp.push_back(prvek);
                }
                sort(BigComp.begin(), BigComp.end());
                BigCompHelp.clear();
            }
            else {
                BigCompHelp.clear();
            }
        }
    }
}

/* Funkce pro pohyb do hloubky */
/* Tato funkce implementuje procházení grafu do hloubky (DFS) počínaje daným indexem.
Ke sledování vrcholů používá zásobník, navštívené vrcholy ukládá do vektoru BigCompHelp a pokračuje v
procházení sousedních vrcholů, označuje je jako navštívené a přidává je do zásobníku. */
void Graph::DFS(int index, vector<int>& BigCompHelp) {
    stack<int> help;
    help.push(index);
    this->visited[index] = true;

    while (!help.empty()) {
        int last = help.top();
        help.pop();
        BigCompHelp.push_back(last);

        for (int prvek : this->adjacencyList[last]) {
            if (!visited[prvek]) {
                visited[prvek] = true;
                help.push(prvek);
            }
        }
    }
}

/* Funkce pro pohyb do  šířky */
/* Tato funkce provede v grafu procházení podle šířky (BFS), počínaje daným vrcholem. K nalezení nejkratší cesty
používá frontu a vzdálenosti od počátečního vrcholu ke každému dalšímu vrcholu ukládá do vektoru dist.
Pokud je některý vrchol nedosažitelný, je mu na konci funkce přiřazena hodnota 0. Funkce vrací vektor vzdáleností. */
vector<int> Graph::BFS(int prvek, int pocetVrcholu) {
    vector<int> dist(pocetVrcholu, pocetVrcholu);
    unordered_map<int, vector<int>> tabulka = this->gate;
    dist[prvek] = 0;
    queue<int> q;
    q.push(prvek);

    while (!q.empty()) {
        int prvni = q.front();
        q.pop();

        for (int prvek : tabulka[prvni]) {
            if (dist[prvek] > dist[prvni] + 1) {
                dist[prvek] = dist[prvni] + 1;
                q.push(prvek);
            }
        }

    }
    for (int i = 0; i < pocetVrcholu; i++) {
        if (dist[i] == pocetVrcholu) {
            dist[i] = 0;
        }
    }
    return dist;
}

/* Funkce pro výstup koeficientu centrality */
/* Tato funkce vypočítá centralitu vrcholu v grafu na základě vektoru vzdálenosti (dist),
daného vrcholu (prvek), celkového počtu vrcholů (pocetVrcholu) a čitatele (citatel). */
void Graph::Centralita(vector<int> dist, int prvek, int pocetVrcholu, int citatel) {
    int sum = 0;
    for (int i = 0; i < pocetVrcholu; i++) {
        if (dist[i] != 0) {
            sum = sum + dist[i];
        }
    }
    float delenie = (float)citatel / sum;
    printf("%d\t%d/%d\t\t%f\n", prvek, citatel, sum, delenie);
}

/* Funkce pro zadávání informací do hashovací tabulky */
/* Tato funkce přidá vrcholy z vektoru BigComp do tabulky bran. Každý vrchol se stává klíčem a jeho odpovídající
seznam přilehlostí je uložen jako hodnota. Funkce vrací velikost tabulky hradel po přidání vrcholů. */
int Graph::MoovDoTabulce(vector<int> BigComp) {
    for (int item : BigComp) {
        this->gate.emplace(item, this->adjacencyList[item]);
    }
    return this->gate.size();
}